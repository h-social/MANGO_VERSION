const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');
const os = require('os');
const paymentsRouter = require('./routes/payments');
const { initDb } = require('./db/sqljs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Configuration
const PORT = process.env.PORT || 3000;
const HOST = 'localhost';

// Store for connected clients
let connectedClients = new Map();

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);
  connectedClients.set(socket.id, socket);

  // Handle client disconnect
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
    connectedClients.delete(socket.id);
  });

  // Handle custom events from WinForm
  socket.on('winform-event', (data) => {
    console.log('Received WinForm event:', data);
    // Broadcast to all connected clients
    io.emit('server-event', {
      type: 'winform-update',
      data: data,
      timestamp: new Date().toISOString()
    });
  });

  // Handle web client events
  socket.on('web-client-event', (data) => {
    console.log('Received web client event:', data);
    // Send to WinForm if needed
    io.emit('winform-command', {
      type: 'web-command',
      data: data,
      timestamp: new Date().toISOString()
    });
  });
});

// API Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    connectedClients: connectedClients.size,
    server: 'Mango Web Server'
  });
});

// API endpoint for WinForm to send data
app.post('/api/winform-data', (req, res) => {
  const data = req.body;
  console.log('Received data from WinForm:', data);
  
  // Broadcast to all connected web clients
  io.emit('winform-data', {
    data: data,
    timestamp: new Date().toISOString()
  });
  
  res.json({ success: true, message: 'Data received and broadcasted' });
});

// API endpoint for web clients to send commands to WinForm
app.post('/api/web-command', (req, res) => {
  const command = req.body;
  console.log('Received command from web client:', command);
  
  // Send command to WinForm
  io.emit('winform-command', {
    command: command,
    timestamp: new Date().toISOString()
  });
  
  res.json({ success: true, message: 'Command sent to WinForm' });
});

// Get server status
app.get('/api/status', (req, res) => {
  res.json({
    server: 'Mango Web Server',
    version: '1.0.0',
    uptime: process.uptime(),
    connectedClients: connectedClients.size,
    timestamp: new Date().toISOString()
  });
});

// Payments API
app.use('/api/payments', paymentsRouter);

(async () => {
  await initDb();
  const payments = require('./db/payments');
  // Xóa payment quá 30 ngày mỗi ngày 1 lần
  setInterval(() => {
    const removed = payments.removeOldPayments(30);
    if (removed > 0) {
      console.log(`Đã tự động xóa ${removed} payment quá 30 ngày`);
    }
  }, 24 * 60 * 60 * 1000); // 24h
  // Gọi luôn khi khởi động server
  payments.removeOldPayments(30);
  // Start server
  server.listen(PORT, HOST, () => {
    console.log(`🚀 Mango Web Server running at http://${HOST}:${PORT}`);
    console.log(`📊 Health check: http://${HOST}:${PORT}/api/health`);
    console.log(`📈 Status: http://${HOST}:${PORT}/api/status`);
    
    // Write server info to temp directory only
    try {
      const serverInfo = {
        url: `http://${HOST}:${PORT}`,
        port: PORT,
        host: HOST,
        pid: process.pid,
        startTime: new Date().toISOString()
      };
      
      // Write to temp directory only (safe for pkg compiled executables)
      const tempDir = os.tmpdir();
      const tempFile = path.join(tempDir, 'mango-server-info.json');
      
      fs.writeFileSync(tempFile, JSON.stringify(serverInfo, null, 2));
      console.log(`📄 Server info written to: ${tempFile}`);
      
    } catch (error) {
      console.log(`⚠️ Could not write server info file: ${error.message}`);
      console.log(`ℹ️ Server is still running normally`);
    }
  });
})();

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down Mango Web Server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down Mango Web Server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

module.exports = { app, server, io }; 